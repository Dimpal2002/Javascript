import React, { useState } from "react";
import { Link,useNavigate } from "react-router-dom";
import { addUserData } from "./UserReducer";
import {useDispatch} from "react-redux"


function AddUser() {
    const [name,setName]= useState(""); 
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const handleSubmit = (e)=>{
        e.preventDefault();
        //dispatch(addUserData({id:users.length+1,name:name}))

        dispatch(addUserData({name:name}))
        navigate("/home")
    }
  return (
    <div>
      <div className="container">
        <div>
          <Link to="/home" className="btn btn-primary my-2"> Back to Home</Link>
        </div>
        <div className="row justify-content-center text-start">
          <div className="col-6">
            <form onSubmit={handleSubmit}>

              <div className="mb-3">
                <label className="form-label">Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e)=>{setName(e.target.value)}}
                  className="form-control"
                  id="exampleInputPassword1"
                />
              </div>

              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddUser;
