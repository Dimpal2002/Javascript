import React, { useEffect, useState } from "react";
import { EditUserData } from "./UserReducer";
import { Link,useNavigate,useParams } from "react-router-dom";

import {useDispatch} from "react-redux"

function EditUser() {

    const [name,setName]= useState(""); 
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const {eid} = useParams();
  
    const handleSubmit = (e)=>{
        e.preventDefault();
        dispatch(EditUserData({id:eid,name:name}))
        navigate("/home")
    }
    useEffect(()=>{
      fetch('http://localhost:4600/users/'+eid)
      .then((res)=>{return res.json()})
      .then((data)=>{setName(data.name)})
    })
  return (
    <div>
      <div className="container">
        <div>
          <Link to="/home" className="btn btn-primary my-2"> Back to Home</Link>
        </div>
        <div className="row justify-content-center text-start">
          <div className="col-6">
            <form onSubmit={handleSubmit}>

              <div className="mb-3">
                <label className="form-label">Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e)=>{setName(e.target.value)}}
                  className="form-control"
                  id="exampleInputPassword1"
                />
              </div>

              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EditUser;
