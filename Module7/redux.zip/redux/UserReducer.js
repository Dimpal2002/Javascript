import { createSlice } from "@reduxjs/toolkit";


const userSlice = createSlice({
  name: "user",
  initialState: [],
  reducers: {
    userData: (state, action) => {
      state.push(action.payload);
    },
    addUserData: (state, action) => {
        // console.log(action.payload)
        fetch('http://localhost:4600/users',{
            method:"post",
            headers:{"content-type":"application/json"},
            body:JSON.stringify(action.payload)
        })

        .then((res)=>{
            if(res)
            {
               alert("Added..!")
               window.location.reload();
            }
        })        
      },

      EditUserData: (state, action) => { 

        console.log(action.payload.id)
        fetch('http://localhost:4600/users/'+action.payload.id,{
            method:"put",
            headers:{"content-type":"application/json"},
            body:JSON.stringify(action.payload)
        })

        .then((res)=>{
            if(res)
            {
               alert("updated..!")
               window.location.reload();
            }
        })
        
      },

      deleteUsers: (state,action)=>{
        fetch('http://localhost:4600/users/'+action.payload.id,{
          method:"DELETE",
          headers:{"content-type":"application/json"},
          body:JSON.stringify(action.payload)
      })

      .then((res)=>{
          if(res)
          {
             alert("Deleted..!")
             window.location.reload();
          }
      })
    }

  },
});

export const { userData,addUserData,EditUserData,deleteUsers } = userSlice.actions;
export default userSlice.reducer;
