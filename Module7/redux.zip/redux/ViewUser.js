import React, { useState } from 'react'
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';


function ViewUser() {

    const [users] = useSelector(state=>state.users);

    const {vid} = useParams();

    const ExistingUser = users.filter((users)=>{
        // console.log(user.id)
        return users.id == vid
    })

    const {name} = ExistingUser[0]

  return (
    <div>
    <div>
        <h2 className="my-3">View User</h2>
    </div>
    <h4>Id:{vid}</h4>
    <h4>Name:{name}</h4>
    </div>
  )
}

export default ViewUser